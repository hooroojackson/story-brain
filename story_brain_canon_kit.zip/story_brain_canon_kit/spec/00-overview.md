# Story Brain Specification Overview

The **Story Brain** is a structural model for building adaptive, AI‑native film narratives. It treats a film as a series of **nodes** (beats, scenes or events) connected by **edges** with conditions, policies and memory updates that guide the story toward one or more **outcomes**. The Story Brain can power “living, breathing” films where the audience, the environment or internal logic determine how the narrative unfolds.

## Key Concepts

- **Node**: A discrete unit of story (beat, scene, shot) with associated content and metadata.
- **Edge**: A link from one node to another, potentially with a **condition** that must be true for the edge to activate.
- **Policy**: A rule that determines which edges to follow, given the current state (e.g., prioritize unresolved character arcs).
- **Memory**: The persistent state of the story engine, storing variables (e.g., which character the viewer selected) and history of visited nodes.
- **Outcome**: A terminal state of the story; for example, ending A vs. ending B.
- **Version hash**: A cryptographic digest identifying the exact set of nodes, edges and policies in a particular release.

## Glossary

This specification defines the foundational terms used in *The New Machine Cinema* and *Post‑Scarcity Cinema*:

| Term | Definition |
| --- | --- |
| **One Person, One Film** | A philosophy where a single director takes on all creative roles, enabled by AI tools, to produce a complete feature. |
| **Story Brain** | The engine at the heart of an adaptive film; it decides what the viewer sees and when based on state and policy. |
| **Adaptive Cinema Engine** | A generalized framework for creating and running Story Brain graphs across films and series. |
| **Speed of the Mind** | The pace at which an AI‑native film can be produced, edit and released when constrained only by the director’s imagination. |
| **The Living, Breathing Cinema** | A film that exists in multiple, evolving forms, changing based on audience choice or other inputs. |
| **Post‑Aesthetic Cinema** | A cinema that prioritizes narrative logic and machine pleasure over visual perfection. |
| **Story Engine** | Synonym for Story Brain in casual contexts; used in contractual credit language. |

See the `story_brain.schema.json` for the formal representation.