# Teaching Kit: Introduction to AI‑Native Cinema and the Story Brain

This two‑week module introduces students to the core concepts of AI‑native filmmaking, using Hooroo Jackson’s **New Machine Cinema** as a case study. It combines film screenings, reading assignments and a small programming exercise.

## Week 1: Foundations

- **Readings:**
  - *The New Machine Cinema* (selected essays: "One Person, One Film", "Speed of the Mind", "The Living, Breathing Cinema").
  - *Post‑Scarcity Cinema* (selected essays: "Machine Pleasures", "Post‑Aesthetic Cinema").
- **Screenings:**
  - *Window Seat* (2023) – the first fully AI feature film (61 min). Focus on how AI performances and visuals work at feature scale.
- **Discussion Questions:**
  1. What does "One Person, One Film" mean in practice? What are the advantages and drawbacks?
  2. How do AI voices and visuals affect viewer perception of performance?
  3. How might "Speed of the Mind" change release cycles and audience expectations?

## Week 2: Adaptive Narratives

- **Readings:**
  - Glossary from the Story Brain specification.
  - Article: "A Very Long Carriage Ride: One Film, Two Ways" (supplemental essay on dual-style release).
- **Screenings:**
  - *DreadClub: Vampire's Verdict* (2024) – the first fully AI animated feature. Pay attention to the sound and music as well as visuals.
- **Workshop:**
  - Use the `examples/avlcr_minimal.json` from this kit to experiment with a simple Story Brain graph. Students can write a script to simulate the node traversal based on a choice variable (e.g., Python pseudocode). Discuss how the engine decides which edges to take.
- **Discussion Questions:**
  1. What distinguishes an "adaptive" film from a linear film? Could you map a familiar film into a Story Brain graph?
  2. How might audience choice or real‑time data influence a Story Brain? What challenges arise in authoring these branches?
  3. If you were to design a new film using the Story Brain, what genres or themes would benefit most from an adaptive approach?

## Assignment

Each student creates a 5–10 node Story Brain graph in JSON, exploring a branching narrative (e.g., two protagonists or two endings). They submit their graph along with a short reflection (500 words) explaining the design decisions and possible viewer experiences.

This teaching kit can be modified for longer or shorter courses. The goal is to give students a practical and conceptual foothold in AI‑native cinema and to connect theory with practice.