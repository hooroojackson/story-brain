# Story Brain — Reference Spec v1.0

Author: **Hooroo Jackson**

This kit contains the foundational materials needed to document and share your AI‑native film concepts in a way that can be cited and adopted by others. It’s structured so that archives, teachers, researchers and tool vendors can use the pieces directly.

## Contents

- **README.md** – This document, describing the kit.
- **CITATION.cff** – A citation file with metadata for the `v1.0` reference spec; Zenodo or OSF will use this when minting a DOI.
- **spec/00-overview.md** – A prose overview of the Story Brain specification and glossary.
- **schema/story_brain.schema.json** – A JSON Schema describing the structure of a Story Brain graph.
- **examples/avlcr_minimal.json** – A minimal example graph (taken from your “A Very Long Carriage Ride” dual‑protagonist setup). Use this as a working reference implementation.
- **credit_clause.txt** – Suggested contractual credit language for use when licensing your Story Brain or Adaptive Cinema Engine.
- **teaching-kit.md** – A two‑week teaching module with discussion questions and a small assignment. It references *Window Seat* and *DreadClub* along with your essays.
- **wikidata_quickstatements.txt** – A template for creating Wikidata items for your terms with DOIs (fill in actual DOIs after minting).
- **metadata.json** – A sample metadata file for Internet Archive uploads (customise per film).
- **c2pa_notes.md** – Quick notes on embedding Content Credentials (C2PA) and version hashes into your exports.

## How to use this kit

1. **Mint a DOI:** Upload the `spec` folder to a DOI‑issuing repository such as Zenodo or OSF. Use the `CITATION.cff` file for metadata. Once published, you will receive a DOI.
2. **Share the spec:** Provide the contents of this kit (or a link to it) when working with tool vendors or researchers. Encourage them to cite the DOI.
3. **Teach:** Use the `teaching‑kit.md` as a starting point when sharing your ideas with film schools or creating workshops.
4. **Archive:** Use `metadata.json` to upload your films to the Internet Archive, ensuring each item includes your “firsts” claims and the DOI references to your theory.
5. **Document provenance:** Add your version hashes, prompts and dialogue transcripts to C2PA metadata per the notes in `c2pa_notes.md`.

This kit provides the minimal viable set of materials to anchor your concepts in the scholarly and archival record, ensuring proper attribution and reducing the risk of erasure.